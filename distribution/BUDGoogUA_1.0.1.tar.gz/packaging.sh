
plugin_name=BUDGoogUA
plugin_version=1.0.1

tar cvfz ../distribution/${plugin_name}_${plugin_version}.tar.gz *
