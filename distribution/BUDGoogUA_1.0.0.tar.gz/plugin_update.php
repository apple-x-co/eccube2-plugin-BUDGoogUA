<?php
/**
 * プラグイン情報
 *
 * @package BUDGoogUA
 * @version 1.0.0
 */
class plugin_update
{
    public function update($arrPlugin)
    {
    }
}